package com.example.myapplication;


interface SmsListener {
    public void messageReceived(String messageBody);
}
